-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2020 at 01:23 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `words`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `status`) VALUES
(1, 'a@gmail.com', '$2y$10$jIK217xK6rEsVmPsBl5mbe5iBVZ1J.BVsnUirjD8ojqcvcQ5.c/HK', 1),
(9, 'b@gmail.com', '$2y$10$cUxjbXKOnhxuLk0mL5tFbeNAy7EUo8jjJDWupb/5HC6hrf5zUnYOm', 1);

-- --------------------------------------------------------

--
-- Table structure for table `words`
--

CREATE TABLE `words` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `word` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meaning` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `words`
--

INSERT INTO `words` (`id`, `user_id`, `word`, `meaning`) VALUES
(1, 1, 'Morning', 'সকাল'),
(2, 1, 'Night', 'রাত'),
(3, 1, 'Absent', 'অনুপস্থিত'),
(4, 1, 'Apple', 'আপেল'),
(5, 1, 'Doll', 'পুতুল'),
(6, 1, 'Cat', 'বিড়াল'),
(7, 1, 'Danger', 'ঝুঁকি'),
(8, 1, 'Ball', 'বল'),
(9, 1, 'Banana', 'কলা'),
(10, 1, 'Ant', 'পিপীলিকা'),
(11, 1, 'Create', 'সৃষ্টি'),
(12, 1, 'Cloth', 'কাপড়'),
(13, 1, 'Connect', 'যুক্ত করা'),
(14, 1, 'Egg', 'ডিম'),
(15, 1, 'Frog', 'ব্যাঙ'),
(16, 1, 'Glass', 'কাচ'),
(17, 1, 'Game', 'খেলা'),
(18, 1, 'Element', 'উপাদান'),
(19, 1, 'Hide', 'আড়াল করা'),
(20, 1, 'Humanity', 'মানবতা'),
(21, 1, 'Ice', 'বরফ'),
(22, 1, 'Journey', 'ভ্রমণ'),
(23, 1, 'Justice', 'বিচার'),
(24, 1, 'Keep', 'রাখা'),
(25, 1, 'Love', 'ভালবাসা'),
(26, 1, 'Orange', 'কমলা'),
(27, 1, 'Purpose', 'উদ্দেশ্য'),
(28, 1, 'Queen', 'রানী'),
(29, 1, 'Request', 'অনুরোধ'),
(30, 1, 'Sleep', 'ঘুম'),
(31, 1, 'Sheep', 'ভেড়া'),
(32, 1, 'Take', 'গ্রহণ করা'),
(33, 1, 'Umbrella', 'ছাতা'),
(34, 1, 'Vacation', 'ছুটি'),
(35, 1, 'Window', 'ছাতা'),
(36, 1, 'Xenophobia', 'বিদেশীদের সম্বন্ধে অহেতুক ভয়'),
(37, 1, 'Yesterday', 'গতকাল'),
(38, 1, 'Zoo', 'চিড়িয়াখানা'),
(39, 1, 'Valid', 'বৈধ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `words`
--
ALTER TABLE `words`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user-words` (`user_id`,`word`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `words`
--
ALTER TABLE `words`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
